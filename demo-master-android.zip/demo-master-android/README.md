# Demo Master для Android

Мастеринг демо в один клик, прямо на телефоне и без интернета.
Внутри тот же движок, что и в веб-версии. Готовые файлы сохраняются в папку «Документы/Demo Master», а кнопка «Поделиться» отправляет их в Telegram, на Диск или в почту.

## Что понадобится

- [Node.js](https://nodejs.org) версии 20 или новее
- [Android Studio](https://developer.android.com/studio) (вместе с ней ставятся Android SDK и Java)

## Сборка APK

1. Распакуйте архив и откройте терминал в папке `demo-master-android`.
2. Установите зависимости и обновите Android-проект:
   ```
   npm install
   npx cap sync android
   ```
3. Откройте проект в Android Studio:
   ```
   npx cap open android
   ```
   Если команда не находит Android Studio, откройте в ней папку `android` вручную.
4. Дождитесь окончания Gradle Sync (при первом запуске это занимает несколько минут).
5. Меню **Build › Build App Bundle(s) / APK(s) › Build APK(s)**.
   Готовый файл: `android/app/build/outputs/apk/debug/app-debug.apk`.
6. Скопируйте APK на телефон и установите его. Android попросит разрешить установку из этого источника.

Чтобы запустить сразу на телефоне, подключите его по USB (включив «Отладку по USB» в настройках разработчика) и нажмите ▶ Run в Android Studio.

## Без Android Studio: сборка на GitHub

В проекте есть готовый сценарий `.github/workflows/build-apk.yml`.
Загрузите папку в свой репозиторий на GitHub, откройте вкладку **Actions › Build APK › Run workflow**.
Через 5–7 минут APK появится в разделе **Artifacts** этого запуска.

## Как менять приложение

Весь интерфейс и обработка звука находятся в `www/index.html`.
После правок выполните `npx cap sync android` и соберите APK заново.

## Для публикации в Google Play

Нужна подписанная сборка: **Build › Generate Signed App Bundle / APK**, формат **Android App Bundle (.aab)**.
Перед этим поменяйте `appId` в `capacitor.config.json` на свой (например, `com.vashe-imya.demomaster`) и выполните `npx cap sync android`.
