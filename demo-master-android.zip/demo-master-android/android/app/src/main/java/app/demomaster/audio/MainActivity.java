package app.demomaster.audio;

import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {}
