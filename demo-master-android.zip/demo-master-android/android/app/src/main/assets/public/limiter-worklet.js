
class DmLimiter extends AudioWorkletProcessor {
  constructor(options) {
    super();
    const o = (options && options.processorOptions) || {};
    this.on = o.on !== false; this.ceil = Math.pow(10, (o.ceil != null ? o.ceil : -1.5) / 20); this.rel = o.rel || 0.08; this.look = o.look || 0.004;
    this.minG = 1; this.cnt = 0; this.reset();
    this.port.onmessage = (e) => {
      const d = e.data || {};
      if ('on' in d) this.on = !!d.on;
      if ('ceil' in d) this.ceil = Math.pow(10, d.ceil / 20);
      if ('rel' in d) this.rel = Math.max(0.005, d.rel);
      if ('look' in d && Math.abs(d.look - this.look) > 1e-6) { this.look = d.look; this.reset(); }
      this.rk = 1 - Math.exp(-1 / (this.rel * sampleRate));
    };
    this.rk = 1 - Math.exp(-1 / (this.rel * sampleRate));
  }
  reset() {
    const N = Math.max(1, Math.round(this.look * sampleRate));
    this.N = N; this.cap = N + 2;
    this.dqv = new Float32Array(this.cap); this.dqi = new Float64Array(this.cap); this.h = 0; this.t = 0; this.n = 0;
    this.ring = new Float32Array(N).fill(1); this.ri = 0; this.sum = N; this.r = 1;
    this.dL = new Float32Array(N); this.dR = new Float32Array(N); this.w = 0;
  }
  process(inputs, outputs) {
    const inp = inputs[0], out = outputs[0];
    if (!out || !out.length) return true;
    const oL = out[0], oR = out[1] || out[0];
    const L = inp && inp.length ? inp[0] : null, R = inp && inp.length > 1 ? inp[1] : L;
    const N = this.N, cap = this.cap, ceil = this.ceil, on = this.on, rk = this.rk;
    for (let i = 0; i < oL.length; i++) {
      const xl = L ? L[i] : 0, xr = R ? R[i] : 0;
      const p = Math.max(Math.abs(xl), Math.abs(xr));
      const d = on && p > ceil ? ceil / p : 1;
      while (this.t > this.h && this.dqv[(this.t - 1) % cap] >= d) this.t--;
      this.dqv[this.t % cap] = d; this.dqi[this.t % cap] = this.n; this.t++;
      while (this.dqi[this.h % cap] <= this.n - N) this.h++;
      const m = this.dqv[this.h % cap];
      this.r = Math.min(m, this.r + (1 - this.r) * rk);
      this.sum += this.r - this.ring[this.ri]; this.ring[this.ri] = this.r; this.ri = (this.ri + 1) % N;
      const g = this.sum / N;
      this.dL[this.w] = xl; this.dR[this.w] = xr;
      const rd = (this.w + 1) % N;
      oL[i] = this.dL[rd] * g; if (oR !== oL) oR[i] = this.dR[rd] * g;
      this.w = rd; this.n++;
      if (g < this.minG) this.minG = g;
    }
    if ((this.cnt += oL.length) >= 2048) { this.port.postMessage({ gr: 20 * Math.log10(Math.max(this.minG, 1e-6)) }); this.cnt = 0; this.minG = 1; }
    return true;
  }
}
registerProcessor('dm-limiter', DmLimiter);
